-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql206.infinityfree.com
-- Generation Time: Aug 20, 2023 at 06:01 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_32728908_portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `visitor_id` int(17) NOT NULL,
  `visitor_name` varchar(35) NOT NULL,
  `visitor_email` varchar(35) NOT NULL,
  `visitor_subject` varchar(255) NOT NULL,
  `visitor_message` text NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`visitor_id`, `visitor_name`, `visitor_email`, `visitor_subject`, `visitor_message`, `timestamp`) VALUES
(1101, 'Test', 'Test@test.com', 'ddd', 'ddd', '2022-10-05 13:06:27'),
(1102, 'Ashraful ', 'alamshihab526@gmail.com', 'Self Visiting', 'Check Message', '2022-10-05 13:06:58'),
(1103, 'JIHAD RAHMAN', 'jihad@ajsysytem.com', 'Brothers Mail', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.', '2022-10-05 06:26:07'),
(1104, 'JIHAD RAHMAN', 'jihad@ajsysytem.com', 'Brothers Mail', 'ttttt', '2022-10-05 14:33:40'),
(1105, 'JIHAD RAHMAN', 'jihad@ajsysytem.com', 'Brothers Mail', 'ttttt', '2022-10-05 14:33:48'),
(1106, 'Zihad ', 'rzihad23@gmail.com', 'Jj', 'Jj', '2022-10-06 13:55:10'),
(1107, 'Test', 'test@mail.com', 'dddd', 'vdvbsdvbsdgbsd', '2022-10-25 07:59:45'),
(1108, 'Test', 'test@mail.com', 'dddd', 'jkhy', '2022-10-30 07:11:39'),
(1109, 'AS', 'alamshihab526@gmail.com', 'Check', 'Hello! How are you', '2022-12-08 10:18:29'),
(1110, 'EE', 'aa@gmail.com', 'dd', 'aa', '2023-03-06 15:35:03'),
(1111, 'EE', 'aa@gmail.com', 'dd', 'dd', '2023-05-07 17:51:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`visitor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `visitor_id` int(17) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
